a = 10;
console.log(a);
let a;