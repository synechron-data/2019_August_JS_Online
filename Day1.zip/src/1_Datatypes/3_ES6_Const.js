// const env = "development";
// console.log(env);

// env = "production";
// console.log(env);

// ------------------------------- Block Scoping
// const env = "development";
// console.log("Outside", env);

// if (true) {
//     const env = "production";
//     console.log("Inside", env);
// }

// ------------------------------- Const with Complex Type
const obj = { id: 1 };

console.log(obj);

obj.id = 100;
// obj = { name: 'hello' };
console.log(obj);
