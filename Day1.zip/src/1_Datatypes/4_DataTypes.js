var language;
console.log("Lauguage is: ", language);
console.log("Type of Lauguage is: ", typeof language);

language = null;
console.log("Lauguage is: ", language);
console.log("Type of Lauguage is: ", typeof language);

// language = 10;
language = 10.5;
console.log("Lauguage is: ", language);
console.log("Type of Lauguage is: ", typeof language);

// language = "JavaScript";
// language = 'JavaScript';
language = `Java

Script`;            // Template Literal
console.log("Lauguage is: ", language);
console.log("Type of Lauguage is: ", typeof language);

language = true;
console.log("Lauguage is: ", language);
console.log("Type of Lauguage is: ", typeof language);

language = Symbol("hello");
console.log("Lauguage is: ", language);
console.log("Type of Lauguage is: ", typeof language);