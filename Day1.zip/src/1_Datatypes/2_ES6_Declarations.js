// let a = 10;
// console.log(a);

// Hoisting - Hoisting is JavaScript's default behavior of moving declarations to the top.
// It will work only when you compile the code
// let keyword is not hoisted by default
// a = 10;
// console.log(a);
// let a;

// let a = 10;
// let a = "Hello";

// console.log(a);

let i = "ABC";
console.log("Before, i is", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside Loop, i is", i);
}

console.log("After, i is", i);

// ES 6 - Scopes
// Global Scope
// Function Scope
// Block Scope - let keyword