// 'use strict'
// console.log("Hello from Declarations File...");

// var a = 10;
// console.log(a);

// Hoisting - Hoisting is JavaScript's default behavior of moving declarations to the top.
// a = 10;
// console.log(a);
// var a;

// Definitions or Initializations are not hoisted
// console.log(a);
// var a = 10;

// var a = 10;
// var a = "Hello";
// console.log(a);

// var i = "ABC";
// console.log("Before, i is", i);

// function Iterate() {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// }

// Iterate();

// console.log("After, i is", i);