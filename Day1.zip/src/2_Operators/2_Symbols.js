// const color1 = "red";
// const color2 = "red";

// // console.log(color1 == color2);
// // console.log(color1 === color2);

// function test(str) {
//     console.log(str === color1);
// }

// test(color1);
// test(color2);
// test("red");

// ----------------------------------------
const color1 = Symbol("red");
const color2 = Symbol("red");

// console.log(color1 == color2);
// console.log(color1 === color2);

function test(str) {
    console.log(str === color1);
}

test(color1);
test(color2);
test("red");
test(Symbol("red"));


// ----------------------------------------
// const color1 = { color: "red" };
// const color2 = { color: "red" };

// // console.log(color1 == color2);
// // console.log(color1 === color2);

// function test(str) {
//     console.log(str === color1);
// }

// test(color1);
// test(color2);
// test({ color: "red" });