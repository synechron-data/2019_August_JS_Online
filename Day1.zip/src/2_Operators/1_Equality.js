// var a = 54;
// var b  = "54";

// // console.log(typeof a);
// // console.log(typeof b);

// var result = a == b;
// console.log(result);

// result = a === b;
// console.log(result);

// var obj1 = {};
// // var obj2 = {};
// var obj2 = obj1;

// console.log(obj1 == obj2);
// console.log(obj1 === obj2);