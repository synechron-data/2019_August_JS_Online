// function hello(name) {
//     if (typeof name != "string")
//         throw Error("Invalid Paramater Type");

//     console.log("Hello,", name);
// }

// hello("Manish");

// hello();
// hello(23);
// hello("Manish", "Pune", 411021);

// try {
//     hello();
// } catch (err) {
//     console.log(err);
// }

// hello("Manish");

// -------------------------------------- Handling less parameters
// function add(x, y) {
//     x = x || 0;
//     y = y || 0;

//     if (((typeof x) == "number") && ((typeof y) == "number"))
//         return x + y;    

//     throw Error("Invalid Paramater Type");
// }

// console.log(add(2, 3));
// console.log(add(2));
// console.log(add());

// console.log(add(2, "ABC"));


// ES 6 - Default Parameters
// function add(x = 0, y = 0) {
//     if (((typeof x) == "number") && ((typeof y) == "number"))
//         return x + y;    

//     throw Error("Invalid Paramater Type");
// }

// console.log(add(2, 3));
// console.log(add(2));

// ---------------------------------------------- Handling Extra Parameters

// function hello(name) {
//     // console.log("Hello,", name);
//     console.log(arguments);
//     for (let i = 0; i < arguments.length; i++) {
//         console.log(arguments[i]);        
//     }
// }

// ES6 - Rest Parameters
// function hello(name, ...args) {
//     console.log("Hello,", name);
//     console.log(args);
// }

// hello("Manish");
// hello("Manish", "Pune");
// hello("Manish", "Pune", 411021);

function average(...numbers) {
    console.log(numbers);
    var sum = 0;

    for (let i = 0; i < numbers.length; i++) {
        sum += numbers[i];
    }

    if (numbers.length)
        return sum / numbers.length;
    else
        return sum;
}

// console.log(average());
// console.log(average(1));
// console.log(average(1, 2));
// console.log(average(1, 2, 3, 4));
// console.log(average(1, 2, 3, 4, 5, 6, 7, 8, 9));

// var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];
// console.log(average(...arr));       // Spread Operator

// Array Spread
// var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];

// console.log(arr);
// console.log(...arr);


// var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];

// // var newArr = arr;
// var newArr = [...arr];

// console.log(arr);
// console.log(newArr);

// newArr[0] = 100;
// console.log(arr);
// console.log(newArr);

// Array Destructuring

var data = [10, 20, 30, 40, 50];

// Array Destructing
// var x = data[0];
// var y = data[1];

// ES 6 - Array Destructing
// var [x, , y] = data;

// console.log("x = " + x + ", y = " + y);

var [x, y, ...z] = data;
console.log("x = " + x + ", y = " + y);
console.log("x = " + x + ", y = " + y + ", z = " + z);