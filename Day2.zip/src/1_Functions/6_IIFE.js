// Immediatly Invoked Function Expression (IIFE)

// function hello() {
//     console.log("Hello World!")
// }

// hello();

// -----------------------------------

// (function () {
//     console.log("Hello World!")
// })();

// (() => {
//     console.log("Hello World!")
// })();

// -----------------------------------

// function hello(name) {
//     console.log("Hello,", name);
// }

// hello("Manish");

(function (name) {
    console.log("Hello,", name);
})("Manish");

((name) => {
    console.log("Hello,", name);
})("Abhijeet");

(name => {
    console.log("Hello,", name);
})("Pravin");