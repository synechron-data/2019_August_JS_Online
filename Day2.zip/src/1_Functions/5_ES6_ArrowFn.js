// function Add1(x, y) {
//     return x + y;
// }

// const Add2 = function (x, y) {
//     return x + y;
// }

// const Add3 = (x, y) => {
//     return x + y;
// }

// const Add4 = (x, y) => x + y;

// console.log(Add1(2, 3));
// console.log(Add2(2, 3));
// console.log(Add3(2, 3));
// console.log(Add4(2, 3));

// --------------------------------------------------------------------------
// Dev 1
// function getString(cb) {
//     const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
//     setInterval(function () {
//         var str = strArr[Math.floor(Math.random() * strArr.length)];
//         cb(str);
//     }, 2000);
// }

// // Dev 2
// getString((s) => {
//     console.log(s);
// });

// ---------------------------------------------------------------------------

var employees = [
    { id: 1, name: "Manish", city: "Pune" },
    { id: 2, name: "Neeraj", city: "Delhi" },
    { id: 3, name: "Pravin", city: "Pune" }
];

// var result = [];

// for (let i = 0; i < employees.length; i++) {
//     if(employees[i].city == "Pune") 
//         result.push(employees[i]);   
// }

// console.log(result);

// ------------------------
// function filterLogic(item){
//     return item.city == "Pune";
// }

// var result = employees.filter(filterLogic);
// console.log(result);

// // ------------------------
// var result = employees.filter(function (item){
//     return item.city == "Pune";
// });
// console.log(result);

// // ------------------------
// var result = employees.filter((item) => {
//     return item.city == "Pune";
// });
// console.log(result);

// ------------------------
// var result = employees.filter((item) => item.city == "Pune");
// console.log(result);

// ------------------------- ES6 - Array Method
// var result = employees.find((item) => item.id == 3);
var result = employees.find((item) => item.city == "Pune");
console.log(result);
