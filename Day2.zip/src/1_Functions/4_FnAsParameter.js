// document.getElementById("b1").addEventListener("click", function (e) {

// })

// $("#b1").click(function () {

// })

// setInterval(function () {
//     console.log(new Date().toTimeString());
// }, 1000);

// // Dev 1
// function getString() {
//     const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
//     var str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// // Dev 2
// // console.log(getString());
// setInterval(function () {
//     console.log(getString());
// }, 2000);

// ----------------------------------------------------------------- Push Data
// Dev 1
function getString(cb) {
    const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
    setInterval(function () {
        var str = strArr[Math.floor(Math.random() * strArr.length)];
        cb(str);
    }, 2000);
}

// Dev 2
getString(function (s) {
    console.log(s);
});