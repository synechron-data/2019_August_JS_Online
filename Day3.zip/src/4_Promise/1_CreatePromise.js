var promise = new Promise((resolve, reject) => {
    setTimeout(function () {
        // resolve("Hello, it is a success call");
        reject("This is a rejection");
    }, 2000);
});

// promise.then((msg) => {
//     console.log(msg);
// }, (eMsg) => {
//     console.error(eMsg);
// })

// promise.then((msg) => {
//     console.log(msg);
// }).catch((eMsg) => {
//     console.error(eMsg);
// });

promise.then((msg) => {
    console.log(msg);
}).catch((eMsg) => {
    console.error(eMsg);
}).finally(()=>{
    console.log("I will always be there!");
})