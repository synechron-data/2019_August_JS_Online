// Dev1
class LocalAPI {
    static getAllPosts(successCB, errorCB) {
        fetch('https://jsonplaceholder.typicode.com/posts').then((response) => {
            var result = response.json();
            result.then(data => {
                successCB(data);
            }).catch(err => {
                errorCB("Parsing Error...");
            })
        }, (err) => {
            errorCB("Communication Error...");
        })
    }

    static getAllPostsUsingPromise() {
        var promise = new Promise((resolve, reject) => {
            fetch('https://jsonplaceholder.typicode.com/posts').then((response) => {
                var result = response.json();
                result.then(data => {
                    resolve(data);
                }).catch(err => {
                    reject("Parsing Error...");
                })
            }, (err) => {
                reject("Communication Error...");
            })
        });
        return promise;
    }
}

// Dev2
document.getElementById("btnJS").addEventListener("click", function (e) {
    // LocalAPI.getAllPosts((data) => {
    //     // Logic to display the data on the UI
    //     console.log(data);
    // }, (eMsg) => {
    //     console.error(eMsg);
    // });

    LocalAPI.getAllPostsUsingPromise().then((data) => {
        // Logic to display the data on the UI
        console.log(data);
    }, (eMsg) => {
        console.error(eMsg);
    });
})

// 1. Chaining Promise
// 2. Promise Methods (All, Race)