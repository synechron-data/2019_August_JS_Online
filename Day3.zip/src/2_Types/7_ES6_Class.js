class Counter {
    constructor(by = 1) {
        this._count = 0;
        this._by = by;
    }

    next() {
        return this._count += this._by;
    }

    prev() {
        return this._count -= this._by;
    }
}

var c1 = new Counter();
console.log(c1.next());
console.log(c1.next());

console.log("\n");

var c5 = new Counter(5);
console.log(c5.next());
console.log(c5.next());