// var toy1 = new Object();
// console.log(toy1)
// console.log(typeof toy1)

// toy1.color = "red";
// console.log(toy1.color)

// console.log(toy1.toString())
// console.log(toy1)
// console.log(Object.prototype)

var toy1 = new Object();
// toy1.color = "red";
Object.prototype.color = "red";

console.log(toy1)

var toy2 = new Object();
toy2.color = "blue";
console.log(toy2)

console.log(toy1.__proto__ === toy2.__proto__);

