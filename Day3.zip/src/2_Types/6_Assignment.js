const Counter = (function () {
    function Counter(by = 1) {
        this._count = 0;
        this._by = by;
    }

    Counter.prototype.next = function () {
        return this._count += this._by;
    }

    Counter.prototype.prev = function () {
        return this._count -= this._by;
    }

    return Counter;
})()

var c1 = new Counter();
console.log(c1.next());
console.log(c1.next());

console.log("\n");

var c5 = new Counter(5);
console.log(c5.next());
console.log(c5.next());