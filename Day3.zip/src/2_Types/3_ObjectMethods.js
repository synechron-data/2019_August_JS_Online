// let target = { a: 1, b: 2 };
// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let obj = source;
// let obj = Object.assign({}, source);        // Shallow Copying
// let obj = JSON.parse(JSON.stringify(source));

// // obj.id = 100;
// obj.address.city = "Mumbai";

// console.log(obj);
// console.log(source);

// ---------------------------------------- Object.create
// Creates a new object, using an existing object as the prototype of the newly created object.
// let target = { a: 1, b: 2 };

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// const newSource = Object.create(source);

// console.log("Source: ", source);
// console.log("newSource: ", newSource);
// // console.log(newSource.id);

// console.log("target: ", target);

// ---------------------------------------- Object.freeze
// let source = { id: 1, name: "Manish" };

// console.log(source);
// // Object.freeze(source);
// // Object.preventExtensions(source);
// // Object.seal(source);

// // source.id = 1000;
// if (!Object.isSealed(source))
//     delete source.id;

// if (Object.isExtensible(source))
//     source.city = "Pune"

// console.log(source);

// ------------------------------------------------ Query
// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let obj = Object.assign({}, source);        // Shallow Copying

// Object.freeze(source.address);

// obj.address.city = "Mumbai";

// console.log(obj);
// console.log(source);