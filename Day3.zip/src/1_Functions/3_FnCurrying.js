// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");
// greetings("Good Morning", "Pravin");

// --------------------------------------------------------------
// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(' km', 1.6, 0, 10));
// console.log(Converter(' km', 1.6, 0, 40));
// console.log(Converter(' km', 1.6, 0, 55));
// console.log(Converter(' km', 1.6, 0, 85));

// ---------------------------------------------- Fn Currying
// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// var mGreet = greetings.bind(this, "Good Morning");

// // mGreet("Abhijeet");
// // mGreet("Ramakant");
// // mGreet("Pravin");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// var milesToKm = Converter.bind(this, ' km', 1.6, 0);

// console.log(milesToKm(10));
// console.log(milesToKm(40));
// console.log(milesToKm(55));
// console.log(milesToKm(85));

// -------------------------------------------------

function greetings(message) {
    return function (name) {
        console.log(`${message}, ${name}`);
    }
}

var mGreet = greetings("Good Morning");

// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");

function Converter(toUnit, factor, offset) {
    return function (input) {
        return [((offset + input) * factor).toFixed(2), toUnit].join("");
    }
}

var milesToKm = Converter(' km', 1.6, 0);

console.log(milesToKm(10));
console.log(milesToKm(40));
console.log(milesToKm(55));
console.log(milesToKm(85));