// function Check() {
//     // console.log(arguments.length);
//     console.log(this);
//     console.log("Check Called...");
// }

// Check();
// Check.call();
// Check.apply();

// Context Setting
// Check();
// Check.call(window);
// Check.apply(window);

// var newCheck = Check.bind(window);
// newCheck();

// --------------------------------------
// function Check(x, y) {
//     console.log(this);
//     console.log("Check Called...");
//     // console.log('x = ' + x, ", y = " + y);
//     // ES6 - Template Literal
//     console.log(`x = ${x}, y = ${y}`);
// }

// Check(2, 3);
// Check.call(window, 2, 3);
// Check.apply(window, [2, 3]);

// ---------------------------------------

// var person1 = {
//     id: 1,
//     name: "Manish",
//     city: "Pune",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// }

// var person2 = {
//     id: 2,
//     name: "Abhijeet",
//     city: "Pune",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// }

// person1.display();
// person2.display();

// ----------------------------------------------

var person1 = {
    id: 1,
    name: "Manish",
    city: "Pune"
}

var person2 = {
    id: 2,
    name: "Abhijeet",
    city: "Pune"
}

function display() {
    console.log(JSON.stringify(this));
}

// display.call(person1);
// display.call(person2);

// Function Borrowing
person1.display = display.bind(person1);
person2.display = display.bind(person2);

person1.display();
person2.display();
