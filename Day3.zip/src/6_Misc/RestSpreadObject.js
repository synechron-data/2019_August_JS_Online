// const numbers = [10, 20, 30, 40, 50];
// var [a, b, ...c] = numbers;        //Rest
// console.log(a)
// console.log(b)
// console.log(c)

// var newArr = [...numbers];          //Spread
// newArr[0] = 100;
// console.log(numbers);
// console.log(newArr);

// ES9 - Object Rest & Spread
var person = { id: 1, name: "Manish", city: "Pune", state: "MH", zip: 411021 };

// var { id, name, ...address } = person;
// console.log(id)
// console.log(name)
// console.log(address)

// var newPerson = Object.assign({}, person);
var newPerson = {...person};        // Object Spread

newPerson.id = 100;
console.log(person);
console.log(newPerson);
