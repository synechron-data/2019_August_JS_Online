var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Varun" },
    { id: 3, name: "Paresh" },
    { id: 4, name: "Devesh" },
    { id: 5, name: "Atul" },
];

// for (let i = 0; i < employees.length; i++) {
//     // console.log(i + "\t" + JSON.stringify(employees[i]));
//     console.log(i + "\t" + employees[i].id + "\t" + employees[i].name);
// }

// console.log(typeof employees);

// for (const key in employees) {
//     console.log(key + "\t" + employees[key].id + "\t" + employees[key].name);
// }

// employees.forEach((item, index, arr)=>{
//     console.log(index + "\t" + item.id + "\t" + item.name);
// })

// ES 2015 - For of Loop

for(const item of employees){
    console.log(item.id + "\t" + item.name);
}