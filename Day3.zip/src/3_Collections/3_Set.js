var set = new Set();

// console.log(set);
// console.log(typeof set);

// set.add(1);
// set.add(2);
// set.add(1);
// set.add(5);
// set.add(5);

// set.add({ id: 1, name: "Manish" });
// set.add({ id: 1, name: "Manish" });

var obj1 = { id: 1, name: "Manish" };
// var obj2 = { id: 1, name: "Manish" };

// set.add(obj1);
// set.add(obj2);

set.add(obj1);
set.add(obj1);

for (const item of set) {
    console.log(item);
}