// import './1_Functions/1_Closure'
// import './1_Functions/2_FnInvocation'
// import './1_Functions/3_FnCurrying'

// import './2_Types/1_ObjectCreation'
// import './2_Types/2_ObjectType'
// import './2_Types/3_ObjectMethods'
// import './2_Types/4_CustomType'
// import './2_Types/5_UsingPrototype'
// import './2_Types/6_Assignment'
// import './2_Types/7_ES6_Class'
// import './2_Types/8_Compare'
// import './2_Types/9_ES5_Properties'
// import './2_Types/10_ES6_Properties'
// import './2_Types/11_ES5_Inheritance'
// import './2_Types/12_ES6_Inheritance'
// import './2_Types/13_StaticMembers'

// import './3_Collections/Array'
// import './3_Collections/1_Map'
// import './3_Collections/2_WeakMap'
// import './3_Collections/3_Set'
// import './3_Collections/4_CustomCollection';

// import './4_Promise/1_CreatePromise'
// import './4_Promise/2_ApiCall'

// import './5_Modules/usage'

import './6_Misc/RestSpreadObject'